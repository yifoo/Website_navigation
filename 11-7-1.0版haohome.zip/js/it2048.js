$("#iptsrh").focus();_indList=new Array(["百度搜索","谷歌搜索","http://www.baidu.com/s?wd=","https://g.weme.so/#newwindow=1&q="],
                                        ["微信搜索","知乎搜索","http://weixin.sogou.com/weixin?p=41351200&type=2&query=","http://zhihu.sogou.com/zhihu?ie=utf8&p=73351201&query="],
                                        ["360指数","淘宝指数","http://index.haosou.com/#trend?q=","http://shu.taobao.com/trendindex?query="],
										["百度搜图","谷歌搜图","http://image.baidu.com/search/index?tn=baiduimage&ipn=r&ct=201326592&cl=2&lm=-1&st=-1&fm=index&fr=&sf=1&fmq=&pv=&ic=0&nc=1&z=&se=1&showtab=0&fb=0&width=&height=&face=0&istype=2&ie=utf-8&word=","https://g.weme.so/search?newwindow=1&hl=zh-TW&site=imghp&tbm=isch&source=hp&biw=1366&bih=611&q="],
                                        ["百度音乐","搜狗音乐","http://music.baidu.com/search?key=","http://mp3.sogou.com/music.so?query="],
										["百度文库","360DOC","http://wenku.baidu.com/search?word=","http://www.360doc.com/search.html?type=0&word="],
                                        ["谷歌学术","百度学术","https://scholar.googto.com/scholar?hl=zh-CN&q=","http://xueshu.baidu.com/s?wd="],
                                        ["百度翻译","谷歌翻译","http://fanyi.baidu.com/translate#zh/en/","http://translate.google.cn/#zh-CN/en/"],
                                        ["佰腾专利","SooPAT","http://so.baiten.cn/results?q=","http://www.soopat.com/Home/Result?searchword="],
                                        ["特百度","磁力搜","http://www.tebaidu.com/search.asp?r=0&wd=","http://www.ciliku.com/main-search.html?kw="],
                                        ["求字体","ChinaZ","http://www.qiuziti.com/fontlist.aspx?fn=","http://aspx.sc.chinaz.com/query.aspx?keyword="]);
_usrslt=0;function show(str){openTag(2,str)}var params={"XOffset":0,"YOffset":0,"width":252,"fontColor":"#000","fontColorHI":"#000","fontSize":"14px","fontFamily":"12px/1.14 arial,\5b8b\4f53;","borderColor":"#D9D9D9","bgcolorHI":"#f1f1f1","sugSubmit":false};
BaiduSuggestion.bind("iptsrh",params,show);$("span[id$='srch']").click(function(){$("span[id$='srch']").attr("class","bgsrh bgsrhnbt");
                                                                                  $(this).attr("class","bgsrh bgsrhbt");_usrslt=$(this).attr("tmp");
                                                                                  $("#srhbt0").html(_indList[_usrslt][0]);if(_indList[_usrslt][1]==""){$("#srhbt1").hide()}else{$("#srhbt1").show();
                                                                                                                                                                                $("#srhbt1").html(_indList[_usrslt][1])}$("#iptsrh").focus()});
function HTMLDeCode(str){var s="";if(str.length==0){return""}s=str.replace("&","%26");
     return s}function openTag(_idstr,_srhstr){ if(_usrslt==1||_usrslt==2||_usrslt==3||_usrslt==4||_usrslt==6||_usrslt==7){_srhstr=encodeURI(_srhstr)}window.open(_indList[_usrslt][_idstr]+HTMLDeCode(_srhstr),"_blank")}
$("button[id^='srhbt']").click(function(){var _idstr=$(this).attr("id");
_idstr=parseInt(_idstr.charAt(_idstr.length-1))+2;_srhstr=$("#iptsrh").val();openTag(_idstr,_srhstr)});
$(document).keydown(function(event){if(event.keyCode==13){_srhstr=$("#iptsrh").val();
                                                          if(_srhstr!=""&&$("[class='bdSug_ml']").html()==null){openTag(2,_srhstr)}}});
function utfToGbk(_str,_url){$.ajaxSetup({async:false});$code="";
$.post("tran.php?f=1",{utf:_str},function(result){$code=result});return $code}$("#categtags1 span").click(function(){sht("1",this)});$("#categtags2 span").click(function(){sht("2",this)});
$("#categtags3 span").click(function(){sht("3",this)});$("#categtags4 span").click(function(){sht("4",this)});
$("#categtags5 span").click(function(){sht("5",this)});$("#categtags6 span").click(function(){sht("6",this)});
function sht(_i,obj){var tmp=new Array();tmp["bgmsc"]=".bgmusic";tmp["bgvdo"]=".bgvedio";tmp["bgbk"]=".bgbook";tmp["bgsft"]=".bgsoft";tmp["bgimga"]=".bgimgae";
                     var _str1="#categtags"+_i+" span";var _str2="#categtags"+_i;var str=tmp[$(obj).attr("class")];$(_str1).css("color","#000");$(obj).css("color","#3ba354");$(_str2).find("p").css("color","#343434");
                     $(_str2).find(str).css("color","#3ba354")}function addFavorite(){if(document.all){try{window.external.addFavorite("http://it2048.cn/","极客导航")}catch(e){alert("加入收藏失败，请使用Ctrl+D进行添加")}}
                                                                                      else{if(window.sidebar){window.sidebar.addPanel("靖风行","http://haohome.applinzi.com/","")}
                                                                                           else{alert("加入收藏失败，请使用Ctrl+D进行添加")}}}function setHomepage(){if(document.all){document.body.style.behavior="url(#default#homepage)";
                                                                                                                                                                        document.body.setHomePage("http://haohome.applinzi.com/")}
                                                                                                                                                       else{if(window.sidebar){if(window.netscape){try{netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect")}
                                                                                                                                                                                                   catch(e){alert("该操作被浏览器拒绝，如果想启用该功能，请在地址栏内输入 about:config,然后将项 signed.applets.codebase_principal_support 值该为true")}}
                                                                                                                                                                               var prefs=Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefBranch);prefs.setCharPref("browser.startup.homepage","http://haohome.applinzi.com/")}
                                                                                                                                                            else{alert("您的浏览器不支持自动自动设置首页, 请使用浏览器菜单手动设置!")}}};
 